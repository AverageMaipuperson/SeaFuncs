<?php
$needsAdmin = false; // Set true if only admins can execute code, set false if not.

$colorCoding = 2; // 1 for classic, 2 for alternate, any other number if disabled

$reportErrors = true; // if set to true, it will stop code execution and show an exception
?>